# NBA 2K20 Black/Red Floating Menu (Android Studio project)

This is a standalone Android floating-menu UI demo. It does not inspect, hook, patch, or modify NBA 2K20, its memory, saves, currency, or online services. The switches are visual UI controls only.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`NBA2K20_BlackRed_Menu`) as an existing Gradle project.
3. Let Gradle sync and install any requested Android SDK components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

## Install and use
1. Install the debug APK on your Android phone.
2. Open **2K20 Black Red Menu** and tap **开启悬浮菜单**.
3. Grant the Android “Display over other apps” permission, return to the app, and tap the button again.
4. Tap the red `2K` bubble to open/close the menu. Drag the bubble to reposition it.

Package: `com.example.nba2k20menu`  
Minimum Android: 6.0 (API 23)

package com.example.nba2k20menu;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {
    private WindowManager wm; private View bubble, panel; private WindowManager.LayoutParams bubbleLp, panelLp;
    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(14));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private TextView label(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER); return t;
    }
    @Override public void onCreate() {
        super.onCreate(); wm = (WindowManager)getSystemService(WINDOW_SERVICE); showBubble();
    }
    private WindowManager.LayoutParams params(int w, int h) {
        int type = android.os.Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(w, h, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
    }
    private void showBubble() {
        bubble = label("2K", 17); bubble.setBackground(bg(Color.rgb(190,20,38), Color.WHITE));
        bubbleLp = params(dp(56), dp(56)); bubbleLp.gravity = Gravity.TOP | Gravity.LEFT; bubbleLp.x = dp(18); bubbleLp.y = dp(180);
        bubble.setOnClickListener(v -> togglePanel());
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { sx=e.getRawX(); sy=e.getRawY(); ox=bubbleLp.x; oy=bubbleLp.y; return false; }
                if (e.getAction() == MotionEvent.ACTION_MOVE) { bubbleLp.x=ox+(int)(e.getRawX()-sx); bubbleLp.y=oy+(int)(e.getRawY()-sy); wm.updateViewLayout(bubble,bubbleLp); return true; }
                return false;
            }
        });
        wm.addView(bubble, bubbleLp);
    }
    private void addToggle(LinearLayout box, String name) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(10), dp(7), dp(10), dp(7));
        TextView title = label(name, 13); title.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT); row.addView(title, new LinearLayout.LayoutParams(0, dp(38), 1));
        TextView toggle = label("OFF", 12); toggle.setTextColor(Color.WHITE); toggle.setBackground(bg(Color.rgb(65,65,72), 0));
        row.addView(toggle, new LinearLayout.LayoutParams(dp(58), dp(30)));
        toggle.setOnClickListener(v -> { boolean on = toggle.getText().equals("OFF"); toggle.setText(on ? "ON" : "OFF"); toggle.setBackground(bg(on ? Color.rgb(190,20,38) : Color.rgb(65,65,72), 0)); });
        box.addView(row);
    }
    private void togglePanel() {
        if (panel != null) { wm.removeView(panel); panel = null; return; }
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(12), dp(10), dp(12), dp(10)); card.setBackground(bg(Color.rgb(17,17,23), Color.rgb(220,35,50)));
        LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("NBA 2K20  |  MOD MENU", 14); title.setTextColor(Color.rgb(255,55,68)); head.addView(title, new LinearLayout.LayoutParams(0, dp(42), 1));
        TextView close = label("✕", 18); head.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38))); close.setOnClickListener(v -> togglePanel()); card.addView(head);
        TextView section = label("LOCAL UI DEMO", 10); section.setTextColor(Color.LTGRAY); section.setGravity(Gravity.LEFT); card.addView(section);
        addToggle(card, "球员能力值预览"); addToggle(card, "投篮训练辅助"); addToggle(card, "体力状态显示"); addToggle(card, "比赛数据面板");
        TextView foot = label("仅界面演示 · 不修改游戏数据", 10); foot.setTextColor(Color.LTGRAY); foot.setPadding(0, dp(8), 0, dp(2)); card.addView(foot);
        panel = card; panelLp = params(dp(280), -2); panelLp.gravity = Gravity.TOP | Gravity.LEFT; panelLp.x = dp(16); panelLp.y = dp(250);
        wm.addView(panel, panelLp);
    }
    @Override public int onStartCommand(Intent i, int f, int id) { return START_NOT_STICKY; }
    @Override public void onDestroy() { if (panel != null) wm.removeView(panel); if (bubble != null) wm.removeView(bubble); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
}

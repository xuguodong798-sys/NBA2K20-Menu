package com.example.nba2k20menu;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER); return t;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER); root.setPadding(dp(24), dp(24), dp(24), dp(24)); root.setBackgroundColor(Color.rgb(12,12,17));
        TextView title = text("NBA 2K20", 28); title.setTextColor(Color.rgb(255,48,59)); root.addView(title);
        TextView sub = text("BLACK / RED FLOATING MENU", 13); sub.setPadding(0, dp(8), 0, dp(30)); root.addView(sub);
        Button start = new Button(this); start.setText("开启悬浮菜单"); start.setTextColor(Color.WHITE); start.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190,25,39)));
        root.addView(start, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView note = new TextView(this); note.setText("独立悬浮菜单演示版\n开关仅用于界面交互，不会修改游戏内存或游戏数据。\n首次使用需要授予“显示在其他应用上层”权限。");
        note.setTextColor(Color.LTGRAY); note.setTextSize(13); note.setGravity(Gravity.CENTER); note.setPadding(0, dp(24), 0, 0); root.addView(note);
        setContentView(root);
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i); Toast.makeText(this, "请允许悬浮窗权限，然后返回再次点击", Toast.LENGTH_LONG).show();
            } else {
                startService(new Intent(this, OverlayService.class));
                Toast.makeText(this, "悬浮菜单已启动", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
